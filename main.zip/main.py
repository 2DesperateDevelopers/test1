from zang import ZangException, Configuration, ConnectorFactory
from zang.configuration.configuration import Configuration
from zang.connectors.connector_factory import ConnectorFactory



def outbound_call():

    try:
        configuration = Configuration('AC777c3e3264f23691dd22493bb593eb8b', '37212001469d4d66bf56b439ba98c509')
        connector_factory = ConnectorFactory(configuration)
        connector = connector_factory.callsConnector

        call = connector.makeCall(
            to='+919524238952',
            from_='+19412003843',
            url='https://api.zang.io/v2/Accounts/AC777c3e3264f23691dd22493bb593eb8b/Agents/DFbf2b4593afb54b969881092a35e8157e/Xml',
            timeout=10,
            )

        print(call.sid)
    except ZangException as ze:
        print(ze)


if __name__ == '__main__':
    outbound_call()

