#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "f9eeaaf9c0"     # abbreviated commit hash
commit = "f9eeaaf9c09ce72cab20165a21dd454be2178c50"  # commit hash
date = "2020-11-18 14:15:50 +0100"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "tag: v4.1, master"  # incl. current branch
commit_message = """Release 4.1.
"""
